import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Actividad Flutter',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0; // 0 = lista, 1 = cardview

  // Lista de lenguajes
  final List<String> languages = [
    "Dart",
    "Java",
    "Python",
    "JavaScript",
    "C#",
    "C++",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Actividad Flutter"),
        backgroundColor: Colors.deepPurple,
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.deepPurple),
              child: Text(
                "Menú de Navegación",
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
            ),
            ListTile(
              leading: Icon(Icons.list),
              title: Text("Lista de Lenguajes"),
              onTap: () {
                setState(() {
                  _selectedIndex = 0;
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.image),
              title: Text("Vista con CardView"),
              onTap: () {
                setState(() {
                  _selectedIndex = 1;
                });
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: _selectedIndex == 0 ? _buildLanguageList() : _buildCardView(),
    );
  }

  // Vista 1: Lista de lenguajes
  Widget _buildLanguageList() {
    return ListView.builder(
      itemCount: languages.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: Icon(Icons.code, color: Colors.blue),
          title: Text(languages[index]),
        );
      },
    );
  }

  // Vista 2: Varias CardView con imagen
Widget _buildCardView() {
  final List<Map<String, String>> cardsData = [
    {
      "title": "Flutter",
      "desc": "Framework para crear apps móviles multiplataforma.",
      "img": "assets/images/flutter-logo.png"
    },
    {
      "title": "Dart",
      "desc": "Lenguaje de programación optimizado para Flutter.",
      "img": "assets/images/dart-logo.png"
    },
    {
      "title": "JavaScript",
      "desc": "Lenguaje popular para desarrollo web.",
      "img": "assets/images/javascript-logo.png"
    },
    {
      "title": "Python",
      "desc": "Lenguaje popular para desarrollo web.",
      "img": "assets/images/python-logo.png"
    },
    {
      "title": "Java",
      "desc": "Lenguaje popular para desarrollo web.",
      "img": "assets/images/java-logo.png"
    },
    {
      "title": "C#",
      "desc": "Lenguaje popular para desarrollo web.",
      "img": "assets/images/c#-logo.png"
    },
    {
      "title": "C++",
      "desc": "Lenguaje popular para desarrollo web.",
      "img": "assets/images/c++-logo.png"
    },
  ];

  return ListView.builder(
    padding: EdgeInsets.all(12),
    itemCount: cardsData.length,
    itemBuilder: (context, index) {
      final card = cardsData[index];
      return Card(
        elevation: 6,
        margin: EdgeInsets.symmetric(vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              child: Image.network(
                card["img"]!,
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    card["title"]!,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    card["desc"]!,
                    textAlign: TextAlign.justify,
                  ),
                ],
              ),
            ),
            ButtonBar(
              alignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {},
                  child: Text("Ver más"),
                ),
              ],
            ),
          ],
        ),
      );
    },
  );
}
}
