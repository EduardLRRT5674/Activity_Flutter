package com.example.flutter_application_activityflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
